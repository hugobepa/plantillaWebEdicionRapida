 <?php include('header.php');?>

            <!--articulos donde rellenar contenido-->
            <!-- clearfix se pone en class para respetar margenes de titulo, escritura  con fotos-->
            <article class="post clearfix">
              
                <!--titulo-->
                 <h2 class="post-title">
                       <a href="#">Primer articulo</a>
                   </h2>
                  <!--fecha y autor-->
                  <p><span class="post-fecha">25/1/1977</span> por <span class="post-autor"><a href="#">Hugo</a></span></p> 
                  <!--contenido articulo-->
                  <p class="post-contenido text-justifity">
              <!--Iniciar Borrar para escribir Articulo-->        

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eu odio ut nulla facilisis molestie vitae sit amet arcu. Sed maximus aliquet tellus, sit amet sagittis quam hendrerit non. Suspendisse eu dui vel elit sollicitudin luctus ut in elit. Donec sed tortor vel mi eleifend commodo. Suspendisse potenti. Nullam quis odio non leo porttitor lobortis ut nec nisl. Sed congue dapibus dolor, non placerat lacus aliquam molestie. Vivamus vitae finibus ante.<br><br>
<pre><code>En cuadrado</code></pre><br>
Donec mollis neque quis malesuada dictum. Vestibulum tincidunt libero fringilla, molestie neque nec, varius magna. Vestibulum vestibulum, justo sed pellentesque scelerisque, ipsum arcu malesuada lacus, ac faucibus nunc dolor in mi. Curabitur eget hendrerit orci, sit amet aliquet ex. Morbi auctor, odio ac pellentesque pellentesque, arcu mauris elementum elit, vitae fermentum felis augue sit amet urna. Duis feugiat condimentum dolor, ut vestibulum felis. Donec mattis lorem eget ante pulvinar iaculis. Nulla vehicula scelerisque mauris, ac tincidunt sem blandit cursus. Cras feugiat, quam ut cursus tempus, dolor lacus semper massa, at placerat felis urna eget augue. In tellus dui, imperdiet nec erat at, dignissim consequat est. Morbi auctor pulvinar malesuada. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Donec cursus pellentesque maximus. Morbi ipsum mi, mollis eu nisi nec, pretium aliquam metus. Nullam convallis ut tortor vel sollicitudin. Duis a neque at turpis volutpat aliquam.<br><br>
      <blockquote>
              <p>Curabitur blandit tempus porttitor. <strong>Nullam quis risus eget urna mollis</strong> ornare vel eu leo. Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
            </blockquote>  
    <!--ul sin numerar y ol numerada-->
        <ul>
              <li>Praesent commodo cursus magna, vel scelerisque nisl consectetur et.</li>
              <li>Donec id elit non mi porta gravida at eget metus.</li>
              <li>Nulla vitae elit libero, a pharetra augue.</li>
            </ul>    
            <!--Acabar Borrar para escribir Articulo-->
             
                  </p>
    <!--botones del articulo-->
                   
            </article>
        <!-- final articulo-->
 
           

<!--footer-->
<?php include('footer.php');?>