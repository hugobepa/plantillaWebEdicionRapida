<!-- Inicia Menu-->
                <!--boton inicio-->
            <div class="collapse navbar-collapse" id="navegacion">
             <ul class="nav navbar-nav">
                 <li class="active"><a href="cookieBasica.php">cookieBasica</a></li>
                 <!--botton con menu deplegable-->
                 <li class="dropdown">
                     <a href="#" class="dropdown-toggle"
                         data-toggle="dropdown"
                             role="button">
                                 Categorias<span class="caret"></span>
                             </a>
                           
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="cookieBasica.php">Cookie basica</a> </li>
                             <li class="divider"> </li>
                             <li><a href="#">Ssegundo</a> </li>
                             <li class="divider"> </li>
                        </ul>
                 </li>
                 <!--botton simple-->
                  <li><a href="#">despues</a></li>   
             </ul>
         <!-- final  Menu hasta /div abajo incluido-->   
        </div> 