   <!--paginacion-->
            <nav>
                <div class="center-block">
                   <ul class="pagination">
                       
                       <li class="active">
                           <a href="cookieBasica.php">cookieBasica.php</a>
                       </li>
                       <li><a href="#">2</a></li>
                       <li><a href="#">3</a></li>
                      
                   </ul>
                    
                </div>
            </nav>