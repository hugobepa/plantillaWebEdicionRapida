<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--favicon html y php-->
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="img/favicon.ico">
<!--SEO-->
<title>PHPSesionesCookies</title>
<meta name="description" content="ejemplos PHP de sesiones y cookies">
<meta name="Keywords" content="tutorial,php,backend,ejemplo,sesiones,cookies" />
<meta name="author" content="hugoberpar"> 
<meta http-equiv="Content-Language" content="es"/> 
<meta name="Distribution" content="global"/>
<meta name=”robots” content="Index,Follow"/>
<meta name=”google” content=”nositelinkssearchbox”>
<!--visualizar diferentes dispositivos-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--utilizar css boostrap y propio-->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/estilos.css" rel="stylesheet">
</head>

<body>
<header>
   <!--cabezera-->
    <nav class="navbar navbar-inverse navbar-static-top" role="navigation">
        <div class="container">
           <!--boton pestañas-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacion">
                    <span class="sr-only">Desplegar/ocultar Menu</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!--titulo No cambiar-->
                <a href="index.php" class="navbar-brand">PHP</a>
            </div>  
            <?php include('barra.php');?>  
               
        </div>
    </nav>
</header>
<!--final header e inicio jumbotron-->
<section class="jumbotron jumbotron-mio">
    <div class="container">
       <!--Cambiar titulo y descripcion-->
        <h1>PHPSesionesCookies</h1>
        <p>Ejemplos de sesiones y cookies en PHP</p>
    </div>
</section>
<?php include('posicionador.php');?>