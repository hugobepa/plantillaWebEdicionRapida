<?php
//cambiar color el php se pone antes del html para conseguir efecto al momento, sino el cambio sera posterior
        //comprobar si llega variable color post
        if(isset($_POST['color'])){
            //guardamos variable del color escogido
            $color=$_POST['color'];
            //creamos cookie con color de elemento escogido
            setcookie('color',$color, time()+36000);
        }else{
            //no utiliza formulario
            if(isset($_COOKIE['color'])){
                //ya habia color escogido
                $color=$_COOKIE['color']; 
            }else{
                //la primera vez que entrar
                $color='white';
            }
        }
        ?>
     

     <html>
      <head>
          <title>Elegir Color web</title>
    <meta charset ="utf-8" />    
    </head>
    <!--pasampos el color escogigo al fondo web mediante CSS-->
    <body  <?php echo"style='background-color:$color'";?>>
        <form method="post" action="elegirColor.php">
            
            <label for="color">Escoger tu color de fondo</label>
            <br>
            <select name="color">
                <option value="red">Rojo</option>
                <option value="blue">azul</option>
                <option value="green">verde</option>
                <option value="yellow">amarillo</option>
                <option value="silver">gris</option>
                <option value="black">negro</option>
            </select>
            <br>
            <input type="submit" value="Caloret!!!!!"/>
        </form>
        
        
        
       
    </body>
</html>
