<?php
session_start();
if(isset($_SESSION['verificado']))
{
    echo "esta es tu pagina privada";
}else{
    header('Location: http://localhost/tutellus/PHPCookies&Sessiones/sessionUsuarioContrasenya.php?error=fuera');
            
            
            die("Your browser does not support redirection. Please go to http://localhost/tutellus/PHPCookies&Sessiones/sessionUsusarioContrasenya.php.");
    
}

?>

     
     
     <html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
        
        
    </body>
</html>
