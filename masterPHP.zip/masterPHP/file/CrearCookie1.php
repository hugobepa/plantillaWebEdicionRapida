<html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
       <!-- action es el fitxer on treballlem y el metodo es post o get-->
        <form action ="CrearCookie1.php" method="post">
        <!-- input es camp type el tipus omplir texty name es el nom del camp -->
            Nombre:<input type="text" name= "nombre"/>
     <!-- input es camp type el tipus botto aceptar y value es nom  que surt el butto -->       
            <input type="submit" value="Enviar!!"/>
        </form>
        
        <?php
        //coge el tipo de valor  $_POST o GET['nombre de valor']
        $nombre = $_POST['nombre'];
        echo "nombre: ".$nombre."<br>"; //funcionCrearCookie(nombreCampo,valorCampo,duracionCookie(funcionTiempoActual+tiempo duracion en segundos))
        setcookie('nombreCookie',$nombre,time()+1800);
        ?>
        
    </body>
</html>