 <?php

   
        $usurlog='hugo';
        $passlog='abcd';
        if($_POST['nombre']==$usurlog && $_POST['pass']==$passlog){
          
            session_start();
            
            //tiene valor si tienes acceso
            $_SESSION["verificado"]="si";
           echo "estas dentro<br>";
            echo"<a href='webUsuario.php'>me la suda's guebs</a>";
        }else{
            
            /*funcion redirigir a una gallleta  con variable y valor incluido
           sessionUsusarioContrasenya.php?error=si") en servidor normal*/
           
          
           
            header('Location: http://localhost/tutellus/PHPCookies&Sessiones/sessionUsuarioContrasenya.php?error=si');
            
            
            die("Your browser does not support redirection. Please go to http://localhost/tutellus/PHPCookies&Sessiones/sessionUsusarioContrasenya.php.");
        }
        ?>