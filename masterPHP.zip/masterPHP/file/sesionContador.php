
       <!-- contador mediante sessiones x usuario y cauntas paginas has visto, cada navegador es usuario distinto-->
        <?php
        session_start();
        if(isset($_SESSION['contador'])){
            $_SESSION['contador']++;    
        }else{
            $_SESSION['contador']= 1;
        }
         echo  "nos  has visitado ".$_SESSION['contador']."<br>";
        ?>
        
 
