<html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
      
        <form action ="crearLeerDestruirCookie.php" method="post">
        
            Crear cookie:<input type="text" name= "nombre"/>
            <input type="submit" value="Enviar!!"/>
            <br><br>
            
            <?php
        //Crear Cookie
        $nombre = $_POST['nombre']; 
        echo "nombre: ".$nombre."<br>"; 
        //nombreCookie,valor, tiempode vida(seg)    
        setcookie($nombre,$nombre,time()+1800);      
        ?>
            
            <br><br>
            Leer Cookie:<input type="text" name= "cookie"/>
           
            <input type="submit" value="Leer!!"/>
            <br>
            <?php
        //visualizar cookie
        $galleta =$_POST["cookie"];
        if(isset($_COOKIE[$galleta])){
            echo "valor galleta: ".$_COOKIE[$galleta]."<br>";
        }else{
            echo "el monstruo de las galletas <br>";
        }      
        ?>
             <br><br>
    Destruir Cookie:<input type="text" name= "destruir"/>
           
            <input type="submit" value="destruir!!"/>
        </form>
        <br>
         <?php
        //visualizar cookie
        $destruir =$_POST["destruir"];
        if(isset($_COOKIE[$destruir])){
    //creamos la galleta en el pasado y se autodestruye
            setcookie($destruir,"",time()-1000);
            echo "galleta destruida<br>";
        }else{
            echo "galleta indestructible <br>";
        }      
        ?>
        
       
        
    </body>
</html>