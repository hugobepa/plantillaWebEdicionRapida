<html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
       
      <?php
        if($_GET[error]=='si'){
            echo "datos erroneos";
        }elseif($_GET[error]=='fuera'){
            echo " no puedes entrar directamente a esta web<br/>";
        }
        ?>
        <p>Hola usuario</p><br/>
        <!-- Ejemplo completo html &  php sobre autentifificion usuario usuario -->
        <!-- Formulario introducir datos -->
        <form action="sessionUsuarioContrasenyaRespuesta.php" method="post">
           <br/>
           <label for "nombre">Nombre de Usuario</label> 
            <input type="text" name="nombre" placeholder="Tu nombre!!!"/>
            
            <br/>
            <label for "pass">Tu contrasenya</label> 
            <input type="password" name="pass"/>
            <br/><br/>
            <input type="submit" value="Enviar!!!!"/>
        </form>
       
    </body>
</html>
