<!--final jumbotron  e inicio parte escrita-->
<section class="main container">
   <!--Breadcrumb definir luegar de la web que estamos-->
    <div class="row">
        <section class="posts col-md-12">
            <div class="miga-de-pan">
                <ol class="breadcrumb">
                    <li><a href="cookieBasica.php">cookieBasica</a></li>
                    <li><a href="#">segon</a></li>
                    <!--pagina donde estamos-->
                    <li class="active">tercer</li>
                </ol>
            </div>