 <?php
        if(isset($_COOKIE['contador'])){
            setcookie('contador', $_COOKIE['contador']+1,time()+(365*24*60*60));
            $mc=$_COOKIE['contador']+1;
            echo "numero visita:".$mc;
            
        }else{
             setcookie('contador',1,time()+(365*24*60*60));
            $mc=$_COOKIE['contador']+1;
            echo "Bienvenido usuario nuevo nv: ".$mc."<br>";
           
        }
        ?>
     <html>
      <head>
          <title>CambiarColorWeb</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
       
        
    </body>
</html>
