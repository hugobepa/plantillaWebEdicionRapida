<html>
      <head>
          <title>FechaUltimaVisita</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
        <!--fecha ultima visita-->
        <?php
        $fecha= date("d/m/Y | H:i:s");
        
        
        
        if(isset($_COOKIE['fecha'])){
            setcookie("fecha",$fecha,time()+31546000);
            echo "ultima visita: ".$_COOKIE['fecha']."<br>";
        }else{
            echo "bienvenido nuevo<br>";
            setcookie("fecha",$fecha,time()+31546000);
        }
        
        ?>
        
    </body>
</html>
