<html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
        <!-- guardar nombre en session-->
        <?php
        //abrir session
        session_start();
        //crear y definir session
        $_SESSION['nombre']='juan';
        ?>
        
        <?php
        //leer session 
        session_start();
    echo "el nombre es ".$_SESSION['nombre']."<br>";
        
        ?>
        
    </body>
</html>
