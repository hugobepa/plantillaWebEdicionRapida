<html>
      <head>
          <title>DetectarNuevasVisitas</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
       <!--si es su primera visita o no-->
        <?php
            if(isset($_COOKIE["visita"])){
                echo "Otra vez por aqui<br>";
            }else{
                //1 año=31536000
                setcookie("visita", "ok", time()+31536000);
                echo"Bienvenido por primera Vez<br>";
            }
        ?>
        
    </body>
</html>
