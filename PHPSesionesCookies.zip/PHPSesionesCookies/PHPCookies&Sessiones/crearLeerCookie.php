<html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
      
        <form action ="crearLeerCookie.php" method="post">
        
            Crear cookie:<input type="text" name= "nombre"/>
            <input type="submit" value="Enviar!!"/>
            <br><br>
            
            <?php
        //Crear Cookie
        $nombre = $_POST['nombre'];
            
        echo "nombre: ".$nombre."<br>"; 
        //nombreCookie,valor, tiempode vida(seg)    
        setcookie($nombre,$nombre,time()+1800);      
        ?>
            
            <br><br>
            Leer Cookie:<input type="text" name= "cookie"/>
           
            <input type="submit" value="Leer!!"/>
            
        </form>
        
        
        
        <?php
        //visualizar cookie
        $galleta =$_POST["cookie"];
        //si una variable esta definida=TRUE ISSSET
        //$_cookie para leer el valor de dentro
        if(isset($_COOKIE[$galleta])){
            echo "valor galleta: ".$_COOKIE[$galleta]."<br>";
        }else{
            echo "el monstruo de las galletas <br>";
        }
        
        ?>
        
    </body>
</html>