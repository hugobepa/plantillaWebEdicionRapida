<html>
      <head>
          <title>Ejercicio</title>
    <meta charset ="utf-8" />    
    </head>
    <body>
          <!--Vamos a guardar loa datos de un usuario en un array nombre, apellido,edad-->
          
            <?php
                $usuario1=array("Hugo","Bermudez",39,"Barcelona","abcde");
                //crear cookies array usuario datos
                setcookie("usuario1[nombre]",$usuario1[0],time()+3600);
                setcookie("usuario1[apellido]",$usuario1[1],time()+3600);
                setcookie("usuario1[edad]",$usuario1[2],time()+3600);
                setcookie("usuario1[ciudad]",$usuario1[3],time()+3600);
                setcookie("usuario1[password]",$usuario1[4],time()+3600);
        
                //llegir cookies
                
                echo "<br/> El nombre es: ".$_COOKIE['usuario1']['nombre'];
                echo "<br/> El apellido es: ".$_COOKIE['usuario1']['apellido'];
                echo "<br/> La edad es: ".$_COOKIE['usuario1']['edad'];
                echo "<br/> La ciudad es: ".$_COOKIE['usuario1']['ciudad'];
                echo "<br/> El password es: ".$_COOKIE['usuario1']['password'];
            ?>
        
    </body>
</html>
