<footer>
    <div class="container">
        <div class="row">
           <!-- sencillo-->
            <div class="col-xs-6">
               <p>Hugo</p>
            </div>
            <!-- listado-->
            <div class="col-xs-6">
            <ul class="list-inline text-right">
                <li><a href="http://www.falconmasters.com/">webTutorial</a> </li>
                <li> <a href="https://www.youtube.com/playlist?list=PLhSj3UTs2_yUrzFL3f2zDwBCKMpAVBBz_">
                youtubeTutorial    
                </a> </li>
                <li><a href="http://www.heroesdelaweb.com">foro</a></li>
                <li><a href="http://getbootstrap.com/getting-started/">bootstrap</a></li>
            </ul>
            </div>  
        </div>
    </div>
    
</footer>
<!--script jquery y bootstrap-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html> 
