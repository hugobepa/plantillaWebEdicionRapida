<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>plantilla</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--favicon html y php-->
<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
<link rel="shortcut icon" href="img/favicon.ico">
<!--SEO-->
<meta name="description" content="php basico aplicacion reales">
<meta name="author" content="hugoberpar">
<meta name="Keywords" content="tutorial,php,backend,ejemplo" /> 
<meta http-equiv="Content-Language" content="es"/> 
<meta name="Distribution" content="global"/>
<meta name=”robots” content="Index,Follow"/>
<meta name=”google” content=”nositelinkssearchbox”>
<!--visualizar diferentes dispositivos-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<!--utilizar css boostrap y propio-->
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/estilos.css" rel="stylesheet">
</head>

<body>
<header>
   <!--cabezera-->
    <nav class="navbar navbar-inverse navbar-static-top" role="navigation">
        <div class="container">
           <!--boton pestañas-->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navegacion">
                    <span class="sr-only">Desplegar/ocultar Menu</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!--titulo-->
                <a href="index.php" class="navbar-brand">PHP</a>
            </div>    
            <!-- Inicia Menu-->
                <!--boton inicio-->
            <div class="collapse navbar-collapse" id="navegacion">
             <ul class="nav navbar-nav">
                 <li class="active"><a href="#">Inicio</a></li>
                 <!--botton con menu deplegable-->
                 <li class="dropdown">
                     <a href="#" class="dropdown-toggle"
                         data-toggle="dropdown"
                             role="button">
                                 Categorias<span class="caret"></span>
                             </a>
                        <ul class="dropdown-menu" role="menu">
                            <li><a href="#">Primera</a> </li>
                             <li class="divider"> </li>
                             <li><a href="#">Ssegundo</a> </li>
                             <li class="divider"> </li>
                        </ul>
                 </li>
                 <!--botton simple-->
                  <li><a href="#">despues</a></li>   
             </ul>
            
        </div>    
        </div>
    </nav>
</header>
<!--final header e inicio jumbotron-->
<section class="jumbotron jumbotron-mio">
    <div class="container">
        <h1>PHP</h1>
        <p>Ayuda con PHP</p>
    </div>
</section>