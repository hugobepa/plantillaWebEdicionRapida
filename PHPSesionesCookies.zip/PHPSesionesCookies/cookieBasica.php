 <?php include('header.php');?>

            <!--articulos donde rellenar contenido-->
            <!-- clearfix se pone en class para respetar margenes de titulo, escritura  con fotos-->
            <article class="post clearfix">
              
                <!--titulo-->
                 <h2 class="post-title">
                       <a href="#">Cookie Basica</a>
                   </h2>
                  <!--fecha y autor-->
                  <p><span class="post-fecha">15/4/2016</span> por <span class="post-autor"><a href="#">hugoberpar</a></span></p> 
                  <!--contenido articulo-->
                  <p class="post-contenido text-justifity">
              <!--Iniciar Borrar para escribir Articulo-->   <h4>Crear Cookie</h4>     
                <?php echo 'form action ="crearLeerDestruirCookie.php" method="post"\<br>
                input type="submit" value="Enviar!!"/<br>
                /form<br>
                //Crear Cookie<br>
            $nombre = $_POST["nombre"];<br>
                echo "nombre: ".$nombre.br;<br>
            //nombreCookie,valor, tiempode vida(seg) <br>   
                setcookie($nombre,$nombre,time()+1800);<br><br>
           ';?>
            <pre><code>
                <form action ="cookieBasica.php" method="post">
        
            Crear cookie:<input type="text" name= "nombre"/>
            <input type="submit" value="Enviar!!"/>
            </form>
            <br>
             <br>
            
            <?php
           //Crear Cookie
             $nombre = $_POST['nombre']; 
            echo "nombre: ".$nombre."<br>"; 
           //nombreCookie,valor, tiempode vida(seg)    
           setcookie($nombre,$nombre,time()+1800);      
        ?>
                     
            </code></pre><br>
            <br><br>
            <h4>Leer Cookie</h4>  
            <?php
             echo'
             form action ="crearLeerDestruirCookie.php" method="post"<br>
              Leer Cookie:input type="text" name= "cookie"/<br> 
            input type="submit" value="Leer!!"/<br>
             /form<br>
            <br>
            <br>
          //visualizar cookie<br>
        $galleta =$_POST["cookie"];<br>
        if(isset($_COOKIE[$galleta])){<br>
            echo "valor galleta: ".$_COOKIE[$galleta]."";<br>
        }else{<br>
            echo "el monstruo de las galletas <br>";<br>
        } <br><br>
              ';            
            ?>    
             
        <pre><code>
               <form action ="crearLeerDestruirCookie.php" method="post">             
               Leer Cookie:<input type="text" name= "cookie"/>
           
            <input type="submit" value="Leer!!"/>
            <br>
            </form>
            <?php
        //visualizar cookie
        $galleta =$_POST["cookie"];
        if(isset($_COOKIE[$galleta])){
            echo "valor galleta: ".$_COOKIE[$galleta]."<br>";
        }else{
            echo "el monstruo de las galletas <br>";
        }      
        ?>                  
                                 
        </code></pre><br>   
         <h4>Destruir Cookie</h4> 
             <?php
               echo '
               form action ="crearLeerDestruirCookie.php" method="post"<br>
               input type="text" name= "destruir"/<br>
            input type="submit" value="destruir!!"/<br>
        /form<br>
        <br>

        //visualizar cookie<br>
        $destruir =$_POST["destruir"];<br>
        if(isset($_COOKIE[$destruir])){<br>
    //creamos la galleta en el pasado y se autodestruye<br>
            setcookie($destruir,"",time()-1000);<br>
            echo "galleta destruida";<br>
        }else{<br>
            echo "galleta indestructible";<br>
        } <br>     
        
               
               
               ';
                ?>
            <pre><code>
             <form action ="cookieBasica.php" method="post">
            <input type="text" name= "destruir"/>
           
            <input type="submit" value="destruir!!"/>
        </form>
        <br>
         <?php
        //visualizar cookie
        $destruir =$_POST["destruir"];
        if(isset($_COOKIE[$destruir])){
    //creamos la galleta en el pasado y se autodestruye
            setcookie($destruir,"",time()-1000);
            echo "galleta destruida<br>";
        }else{
            echo "galleta indestructible <br>";
        }      
         ?>   
            
            </code></pre><br>                                                          
            <!--Acabar Borrar para escribir Articulo-->
             
                  </p>
    <!--DOCUMENTACION-->
              <br><br>
              <h4>Archivo</h4>
<a href="file/crearLeerDestruirCookie.php" download="crearLeerDestruirCookie.php">crearLeerDestruirCookie.php </a>
               <BR>
                <h4>Documentación</h4>
                   <ul>
                      <li><a href="http://php.net/manual/es/reserved.variables.post.php">$_POST</a></li>
                       <li><a href="http://php.net/manual/es/reserved.variables.cookies.php">$_COOKIE</a></li>
                       <li><a href="http://php.net/manual/es/function.setcookie.php">setcookie</a></li>
                        <li><a href="http://php.net/manual/es/function.isset.php">isset</a></li>
                   </ul>
                   
                   
                   
                   
            <!-- final articulo-->       
            </article>
       
 
           

<!--footer-->
<?php include('footer.php');?>