
   
 <!-- final articulo-->
         
            <?php include('paginador.php');?>
            <!--final area de contenido-->
        </section> 
        
        
        
        
    </div>
    <!-- final area principal de contenidos-->
</section>
   <footer>
    <div class="container">
        <div class="row">
           <!-- sencillo-->
            <div class="col-xs-6">
               <p>hugoberpar</p>
            </div>
            <!-- listado-->
            <div class="col-xs-6">
            <ul class="list-inline text-right">
               <li><a href="https://www.tutellus.com/tecnologia/desarrollo-web/implementar-cookies-y-sesiones-en-php-4178">PHP cookies y sesiones</a> </li>
                <li><a href="http://www.falconmasters.com/">webTutorial</a> </li>
                <li> <a href="https://www.youtube.com/playlist?list=PLhSj3UTs2_yUrzFL3f2zDwBCKMpAVBBz_">
                youtubeTutorial    
                </a> </li>
                <li><a href="http://www.heroesdelaweb.com">foro</a></li>
                <li><a href="http://getbootstrap.com/getting-started/">bootstrap</a></li>
            </ul>
            </div>  
        </div>
    </div>
    
</footer>
<!--script jquery y bootstrap-->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>

</html> 
