 <?php include('header.php');?>

            <!--articulos donde rellenar contenido-->
            <!-- clearfix se pone en class para respetar margenes de titulo, escritura  con fotos-->
            <article class="post clearfix">
              
                <!--titulo-->
                 <h2 class="post-title">
                       <a href="#">Primer articulo</a>
                   </h2>
                  <!--fecha y autor-->
                  <p><span class="post-fecha">25/1/1977</span> por <span class="post-autor"><a href="#">Hugo</a></span></p> 
                  <!--contenido articulo-->
                  <p class="post-contenido text-justifity">
              <!--Iniciar Borrar para escribir Articulo-->        
              <!--escribir en este sitio-->

                      
            <!--Acabar Borrar para escribir Articulo-->
             
                  </p>
    <!--botones del articulo-->
                   
            </article>
        <!-- final articulo-->
 
           

<!--footer-->
<?php include('footer.php');?>