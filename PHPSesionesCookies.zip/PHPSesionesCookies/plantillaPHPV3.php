 <?php include('header.php');?>

            <!--articulos donde rellenar contenido-->
            <!-- clearfix se pone en class para respetar margenes de titulo, escritura  con fotos-->
            <article class="post clearfix">
              
                <!--titulo-->
                 <h2 class="post-title">
                       <a href="#">Cookie Basica</a>
                   </h2>
                  <!--fecha y autor-->
                  <p><span class="post-fecha">15/4/2016</span> por <span class="post-autor"><a href="#">hugoberpar</a></span></p> 
                  <!--contenido articulo-->
                  <p class="post-contenido text-justifity">
              <!--Iniciar Borrar para escribir Articulo-->   <h4>Crear Cookie</h4>     
                <?php echo 'form action ="crearLeerDestruirCookie.php" method="post"\<br><br>
                
                //Crear Cookie<br>
            $nombre = $_POST["nombre"];<br>
                echo "nombre: ".$nombre.br;<br>
            //nombreCookie,valor, tiempode vida(seg) <br>   
                setcookie($nombre,$nombre,time()+1800);<br><br>
           ';?>
            <pre><code>
                 Crear cookie:<input type="text" name= "nombre"/>
            <input type="submit" value="Enviar!!"/>
            <br><br>
            
            <?php
           //Crear Cookie
             $nombre = $_POST['nombre']; 
            echo "nombre: ".$nombre."<br>"; 
           //nombreCookie,valor, tiempode vida(seg)    
           setcookie($nombre,$nombre,time()+1800);      
        ?>
                     
            </code></pre><br>
                      
            <!--Acabar Borrar para escribir Articulo-->
             
                  </p>
    <!--DOCUMENTACION-->
              <br><br>
              <h4>Archivo</h4>
<a href="file/crearLeerDestruirCookie.php" download="crearLeerDestruirCookie.php">crearLeerDestruirCookie.php </a>
               <BR>
                <h4>Documentación</h4>
                   <ul>
                      <li><a href="http://php.net/manual/es/reserved.variables.post.php">$_POST</a></li>
                       <li><a href="http://php.net/manual/es/reserved.variables.cookies.php">$_COOKIE</a></li>
                       <li><a href="http://php.net/manual/es/function.setcookie.php">setcookie</a></li>
                   </ul>
            </article>
        <!-- final articulo-->
 
           

<!--footer-->
<?php include('footer.php');?>